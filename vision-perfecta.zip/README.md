# Visión Perfecta - Página Web

Sitio web minimalista y formal para promocionar gafas.  
Contiene navegación interactiva y secciones dinámicas (Inicio, Productos, Contacto).

👉 **Vista previa:** Una vez subido, lo podrás ver en:  
`https://tuusuario.github.io/vision-perfecta/`